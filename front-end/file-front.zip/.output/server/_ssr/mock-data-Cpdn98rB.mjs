import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mock-data-Cpdn98rB.js
var import_jsx_runtime = require_jsx_runtime();
function PageHeader({ titre, description, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:flex-wrap sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "truncate text-2xl font-semibold tracking-tight text-foreground sm:text-3xl",
				children: titre
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: description
			})]
		}), action]
	});
}
var iconeSvg = (concept) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="#12B331" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
  <title>${concept}</title>
  <circle cx="32" cy="32" r="22" />
  <path d="M20 36c6-10 18-10 24 0" />
  <path d="M32 14v8M32 42v8" />
</svg>`;
iconeSvg("Diplôme numérique"), iconeSvg("Partenariat international"), iconeSvg("Laboratoire de recherche"), iconeSvg("Bibliothèque en ligne"), iconeSvg("Réseau étudiant"), iconeSvg("Certification qualité");
var pipelineEtapes = [
	{
		nom: "Concept",
		detail: "Saisie utilisateur normalisée"
	},
	{
		nom: "Brand Reader",
		detail: "Lecture de la charte ISPM"
	},
	{
		nom: "SVG Analyzer",
		detail: "Analyse des références existantes"
	},
	{
		nom: "Prompt Builder",
		detail: "Construction du prompt contraint"
	},
	{
		nom: "LLM",
		detail: "Inférence du modèle sélectionné"
	},
	{
		nom: "Génération SVG",
		detail: "Sortie vectorielle brute"
	},
	{
		nom: "Validation",
		detail: "Contrôles XML, palette, stroke"
	},
	{
		nom: "Score",
		detail: "Note de conformité globale"
	}
];
var validations = [
	{
		critere: "SVG valide",
		statut: "réussi",
		detail: "Balise <svg> conforme"
	},
	{
		critere: "XML valide",
		statut: "réussi",
		detail: "Arbre bien formé"
	},
	{
		critere: "ViewBox",
		statut: "réussi",
		detail: "0 0 64 64"
	},
	{
		critere: "Palette",
		statut: "réussi",
		detail: "Couleurs issues de la charte"
	},
	{
		critere: "Stroke",
		statut: "avertissement",
		detail: "3 px attendu, 2,8 px détecté"
	},
	{
		critere: "Nombre de couleurs",
		statut: "réussi",
		detail: "2 / 3 autorisées"
	}
];
//#endregion
export { pipelineEtapes as n, validations as r, PageHeader as t };
