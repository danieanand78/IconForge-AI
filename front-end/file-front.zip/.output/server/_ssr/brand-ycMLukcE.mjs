//#region node_modules/.nitro/vite/services/ssr/assets/brand-ycMLukcE.js
/**
* Configuration centrale de la marque.
* Modifier ce fichier suffit pour changer le logo, le nom et la palette.
* Les couleurs sont définies en oklch dans src/styles.css (tokens sémantiques).
*/
var brand = {
	name: "IconForge AI",
	organisation: "ISPM",
	baseline: "Génération d'icônes SVG guidée par la charte de marque",
	logoUrl: "/logo_ispm.png",
	/** Palette officielle (référence visuelle, source de vérité : src/styles.css) */
	palette: [
		{
			nom: "Vert ISPM",
			hex: "#12B331",
			usage: "Couleur primaire, accents, CTA"
		},
		{
			nom: "Vert profond",
			hex: "#0A6E20",
			usage: "Dégradés, états actifs"
		},
		{
			nom: "Vert clair",
			hex: "#7CE88F",
			usage: "Survols, indicateurs positifs"
		},
		{
			nom: "Noir graphite",
			hex: "#111413",
			usage: "Texte principal, aplats"
		},
		{
			nom: "Gris ardoise",
			hex: "#5B6660",
			usage: "Texte secondaire"
		},
		{
			nom: "Blanc cassé",
			hex: "#F7FAF8",
			usage: "Fonds, surfaces"
		}
	]
};
/** Configuration de l'API FastAPI (branchement futur) */
var apiConfig = {
	baseUrl: {
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/"
	}["VITE_API_URL"] ?? "http://localhost:8000",
	endpoints: {
		generate: "/api/v1/generate",
		validate: "/api/v1/validate",
		history: "/api/v1/history",
		brand: "/api/v1/brand",
		health: "/api/v1/health"
	}
};
//#endregion
export { brand as n, apiConfig as t };
