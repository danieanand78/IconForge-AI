import { n as __toESM } from "../_runtime.mjs";
import { t as apiConfig } from "./brand-ycMLukcE.mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as pipelineEtapes, t as PageHeader } from "./mock-data-Cpdn98rB.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as Download, c as ChevronDown, i as ExternalLink, o as Copy, r as LoaderCircle, s as ChevronRight } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/generer-qkRhpmL3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PipelineViz({ etapeActive = -1 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-card p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-baseline justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-semibold text-foreground",
				children: "Pipeline IA"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Concept → Brand Reader → SVG Analyzer → Prompt Builder → LLM → SVG → Validation → Score"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-4 flex flex-col gap-3 lg:flex-row lg:items-stretch lg:overflow-x-auto lg:pb-2",
			children: pipelineEtapes.map((etape, i) => {
				const fait = etapeActive >= i && etapeActive >= 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex min-w-0 flex-1 flex-col items-stretch gap-2 lg:flex-row lg:items-center lg:min-w-[11rem]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: ["min-w-0 rounded-xl border p-3 transition-colors", etapeActive === i ? "border-primary bg-primary/10" : fait ? "border-primary/40 bg-primary/5" : "border-border bg-background"].join(" "),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-xs font-semibold text-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: ["grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px]", fait ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"].join(" "),
								children: i + 1
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "break-words",
								children: etape.nom
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 break-words text-[11px] text-muted-foreground",
							children: etape.detail
						})]
					}), i < pipelineEtapes.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
						"aria-hidden": "true",
						className: "mx-auto h-4 w-4 shrink-0 text-muted-foreground lg:hidden"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
						"aria-hidden": "true",
						className: "hidden h-4 w-4 shrink-0 text-muted-foreground lg:block"
					})] })]
				}, etape.nom);
			})
		})]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
function Generer() {
	const [concept, setConcept] = (0, import_react.useState)("");
	const [enCours, setEnCours] = (0, import_react.useState)(false);
	const [etape, setEtape] = (0, import_react.useState)(-1);
	const [resultat, setResultat] = (0, import_react.useState)(null);
	const generer = async () => {
		const conceptNettoye = concept.trim();
		if (!conceptNettoye) {
			toast.error("Veuillez saisir un concept.");
			return;
		}
		setEnCours(true);
		setResultat(null);
		setEtape(0);
		let i = 0;
		const timer = window.setInterval(() => {
			i += 1;
			setEtape(i);
			if (i >= pipelineEtapes.length - 1) window.clearInterval(timer);
		}, 320);
		try {
			const response = await fetch(`${apiConfig.baseUrl}${apiConfig.endpoints.generate}`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ concept: conceptNettoye })
			});
			const payload = await response.json();
			if (!response.ok || !payload.svg) throw new Error(payload.error ?? "La génération a échoué.");
			window.clearInterval(timer);
			setEtape(pipelineEtapes.length - 1);
			setResultat({
				svg: payload.svg,
				score: payload.score ?? 0,
				concept: payload.concept ?? conceptNettoye
			});
		} catch (error) {
			window.clearInterval(timer);
			setEtape(-1);
			toast.error(error instanceof Error ? error.message : "Impossible de joindre l'API.");
		} finally {
			setEnCours(false);
		}
	};
	const telecharger = () => {
		if (!resultat) return;
		const url = URL.createObjectURL(new Blob([resultat.svg], { type: "image/svg+xml" }));
		const a = document.createElement("a");
		a.href = url;
		a.download = `${resultat.concept.replace(/\s+/g, "-").toLowerCase()}.svg`;
		a.click();
		URL.revokeObjectURL(url);
		toast.success("Icône téléchargée.");
	};
	const copier = async () => {
		if (!resultat) return;
		await navigator.clipboard.writeText(resultat.svg);
		toast.success("Code SVG copié.");
	};
	const ouvrir = () => {
		if (!resultat) return;
		const url = URL.createObjectURL(new Blob([resultat.svg], { type: "image/svg+xml" }));
		window.open(url, "_blank", "noopener");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				titre: "Générer une icône",
				description: "Décrivez un concept, l'IA produit une icône SVG conforme à votre charte."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[minmax(0,1fr)_360px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "concept",
							className: "text-sm font-medium text-foreground",
							children: "Concept"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-col gap-2 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "concept",
								value: concept,
								onChange: (e) => setConcept(e.target.value),
								onKeyDown: (e) => e.key === "Enter" && generer(),
								placeholder: "ex. remise de diplôme, laboratoire, partenariat…",
								className: "min-w-0"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: generer,
								disabled: enCours,
								className: "shrink-0",
								children: [enCours && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-4 w-4 animate-spin" }), enCours ? "Génération…" : "Générer"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted-foreground",
							children: "Génération effectuée par le pipeline IconForge local."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 grid place-items-center rounded-xl border border-dashed border-border bg-background p-10",
							children: resultat ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-40 w-40 [&_svg]:h-full [&_svg]:w-full",
								dangerouslySetInnerHTML: { __html: resultat.svg }
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: enCours ? "Génération en cours…" : "L'aperçu SVG s'affichera ici."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: telecharger,
									disabled: !resultat,
									className: "group transition-all duration-200 hover:-translate-y-0.5 hover:border-primary-foreground hover:bg-primary hover:text-primary-foreground hover:shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4 transition-transform group-hover:-translate-y-0.5" }), "Télécharger"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: copier,
									disabled: !resultat,
									className: "group transition-all duration-200 hover:-translate-y-0.5 hover:border-primary-foreground hover:bg-primary hover:text-primary-foreground hover:shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4 transition-transform group-hover:scale-110" }), " Copier"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "outline",
									onClick: ouvrir,
									disabled: !resultat,
									className: "group transition-all duration-200 hover:-translate-y-0.5 hover:border-primary-foreground hover:bg-primary hover:text-primary-foreground hover:shadow-md",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-4 w-4 transition-transform group-hover:translate-x-0.5" }), "Ouvrir"]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold text-foreground",
							children: "Score de génération"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 text-5xl font-semibold tracking-tight text-primary",
							children: [resultat ? resultat.score : "—", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg text-muted-foreground",
								children: " / 100"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 h-2 w-full overflow-hidden rounded-full bg-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-primary transition-all duration-500",
								style: { width: `${resultat?.score ?? 0}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-6 space-y-2 text-sm",
							children: [
								["Conformité palette", resultat ? "100 %" : "—"],
								["Géométrie", resultat ? "94 %" : "—"],
								["Épaisseur de trait", resultat ? "88 %" : "—"],
								["Lisibilité 16 px", resultat ? "92 %" : "—"]
							].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 truncate text-muted-foreground",
									children: k
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 font-medium text-foreground",
									children: v
								})]
							}, k))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PipelineViz, { etapeActive: resultat ? pipelineEtapes.length - 1 : etape })
		]
	});
}
//#endregion
export { Generer as component };
