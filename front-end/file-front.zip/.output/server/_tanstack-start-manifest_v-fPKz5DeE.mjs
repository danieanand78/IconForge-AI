//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-fPKz5DeE.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/unknown/Documents/icon-forge-ai-main/front-end/src/routes/__root.tsx",
		children: [
			"/",
			"/generer",
			"/validation"
		],
		preloads: ["/assets/index-DjlZknuF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DjlZknuF.js"
		} }]
	},
	"/generer": {
		filePath: "/home/unknown/Documents/icon-forge-ai-main/front-end/src/routes/generer.tsx",
		children: void 0,
		preloads: ["/assets/generer-46mMgHND.js", "/assets/mock-data-CSQmTAnU.js"]
	},
	"/validation": {
		filePath: "/home/unknown/Documents/icon-forge-ai-main/front-end/src/routes/validation.tsx",
		children: void 0,
		preloads: ["/assets/validation-BjJz6oop.js", "/assets/mock-data-CSQmTAnU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
